# Módulo inicial da Loja Digital Toplevel

Este pacote acrescenta a base de administração e catálogo genérico à estrutura PHP atual. Não é exclusivo do LocaTop: produtos futuros usam o mesmo cadastro.

## O que está incluído
- Banco MySQL para administradores, produtos, clientes, pedidos, pagamentos, downloads, licenças, ativações e eventos de gateway.
- Login administrativo com senha armazenada por `password_hash()`.
- Painel inicial com indicadores e pedidos recentes.
- Cadastro/edição de produtos genéricos.
- Catálogo público em `loja.php` e página de detalhe em `produto.php`.
- Diretório `storage` bloqueado para acesso HTTP.

## Instalação
1. Faça backup do site atual.
2. Crie um banco MySQL (ou importe `database/schema.sql`, que cria `toplevel_loja`).
3. Edite `config/store.php` com host, nome do banco, usuário e senha MySQL.
4. Garanta que `storage/downloads` e `storage/logs` tenham permissão de escrita pelo PHP, sem permitir execução de scripts.
5. Acesse `admin/criar-admin.php` uma única vez e crie o administrador. **Depois de criar, apague `admin/criar-admin.php` do servidor.**
6. Acesse `admin/login.php`, cadastre os produtos e publique-os.
7. Acesse `loja.php` para ver o catálogo público.

## Importante: estágio atual
O checkout e a integração com gateway ainda não estão ativos. A página do produto informa isso claramente; não existe simulação de pagamento. A próxima etapa é integrar um gateway escolhido, validar webhook no servidor, criar pedidos/clientes e liberar links temporários após confirmação real. O envio de e-mail SMTP também será configurado nessa etapa.

O campo `download_file` no cadastro é uma referência planejada; a rotina segura de upload/download ainda não foi ativada. Não coloque instaladores em pastas públicas.

## Segurança antes de produção
- Use HTTPS.
- Proteja `config/store.php` e mantenha credenciais fora do Git.
- O usuário MySQL deve ter permissões apenas no banco da loja.
- Restrinja o acesso administrativo (senha forte; idealmente MFA ou proteção adicional no servidor).
- Configure backup do MySQL e dos arquivos privados.
- Revise política de privacidade, termos de compra, cancelamento/reembolso e emissão fiscal.
