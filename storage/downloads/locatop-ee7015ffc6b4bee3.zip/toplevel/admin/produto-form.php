<?php
require __DIR__ . '/_init.php';
store_admin_required();

$pdo = store_db();
$id = (int)($_GET['id'] ?? 0);
$error = '';
$success = '';

$p = [
    'name' => '', 'slug' => '', 'category' => 'Software',
    'short_description' => '', 'description' => '', 'price' => '0.00',
    'license_type' => 'perpetual', 'max_activations' => 1,
    'version' => '1.0.0', 'cover_image' => '', 'file_path' => '',
    'is_published' => 0
];

if ($id > 0) {
    $q = $pdo->prepare('SELECT * FROM products WHERE id = ? LIMIT 1');
    $q->execute([$id]);
    $found = $q->fetch();
    if (!$found) {
        http_response_code(404);
        exit('Produto não encontrado.');
    }
    $p = array_merge($p, $found);
}

/**
 * Salva um upload com nome aleatório, evitando sobrescrever arquivos.
 * Retorna o caminho relativo salvo no banco.
 */
function store_save_upload(array $file, string $kind): ?string {
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Falha no envio do arquivo. Código: ' . (int)$file['error']);
    }

    $maxImage = 5 * 1024 * 1024;       // 5 MB
    $maxInstaller = 500 * 1024 * 1024; // 500 MB
    $max = $kind === 'image' ? $maxImage : $maxInstaller;

    if ((int)$file['size'] <= 0 || (int)$file['size'] > $max) {
        throw new RuntimeException($kind === 'image'
            ? 'A imagem deve ter no máximo 5 MB.'
            : 'O instalador deve ter no máximo 500 MB.');
    }

    $original = (string)($file['name'] ?? '');
    $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));

    if ($kind === 'image') {
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];
        if (!in_array($ext, $allowed, true)) {
            throw new RuntimeException('A capa deve estar em JPG, PNG ou WEBP.');
        }
        $tmp = (string)$file['tmp_name'];
        $info = @getimagesize($tmp);
        if ($info === false) {
            throw new RuntimeException('O arquivo enviado não é uma imagem válida.');
        }
        $mime = (string)($info['mime'] ?? '');
        $mimeExt = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        if (!isset($mimeExt[$mime])) {
            throw new RuntimeException('Formato de imagem não permitido.');
        }
        $ext = $mimeExt[$mime];
        $relativeDir = 'assets/uploads/products';
        $absoluteDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . $relativeDir;
    } else {
        $allowed = ['zip', 'exe', 'msi'];
        if (!in_array($ext, $allowed, true)) {
            throw new RuntimeException('O instalador deve ser ZIP, EXE ou MSI.');
        }
        $absoluteDir = defined('STORE_DOWNLOAD_DIR')
            ? STORE_DOWNLOAD_DIR
            : dirname(__DIR__) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'downloads';
        $relativeDir = 'storage/downloads';
    }

    if (!is_dir($absoluteDir) && !mkdir($absoluteDir, 0750, true) && !is_dir($absoluteDir)) {
        throw new RuntimeException('Não foi possível criar a pasta de armazenamento dos arquivos.');
    }

    $filename = bin2hex(random_bytes(16)) . '.' . $ext;
    $destination = rtrim($absoluteDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $filename;

    if (!move_uploaded_file((string)$file['tmp_name'], $destination)) {
        throw new RuntimeException('Não foi possível armazenar o arquivo enviado. Verifique as permissões da pasta.');
    }

    return $relativeDir . '/' . $filename;
}

function store_remove_managed_file(?string $relativePath, string $kind): void {
    if (!$relativePath) return;
    $base = $kind === 'image'
        ? dirname(__DIR__) . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'products'
        : (defined('STORE_DOWNLOAD_DIR') ? STORE_DOWNLOAD_DIR : dirname(__DIR__) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'downloads');

    $realBase = realpath($base);
    $candidate = realpath(dirname(__DIR__) . DIRECTORY_SEPARATOR . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $relativePath));
    if ($kind === 'installer' && $realBase) {
        $candidate = realpath($realBase . DIRECTORY_SEPARATOR . basename($relativePath));
    }
    if ($realBase && $candidate && strpos($candidate, $realBase . DIRECTORY_SEPARATOR) === 0 && is_file($candidate)) {
        @unlink($candidate);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    store_check_csrf();

    foreach (['name','slug','category','short_description','description','price','license_type','version'] as $key) {
        $p[$key] = trim((string)($_POST[$key] ?? ''));
    }
    $p['max_activations'] = max(1, (int)($_POST['max_activations'] ?? 1));
    $p['is_published'] = (int)($_POST['is_published'] ?? 0) === 1 ? 1 : 0;

    if ($p['slug'] === '') $p['slug'] = $p['name'];
    $slugSource = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $p['slug']);
    $p['slug'] = strtolower(trim((string)preg_replace('/[^a-zA-Z0-9]+/', '-', (string)$slugSource), '-'));

    if ($p['name'] === '' || $p['slug'] === '' || $p['short_description'] === '') {
        $error = 'Preencha nome, endereço e resumo do produto.';
    } elseif (!is_numeric($p['price']) || (float)$p['price'] < 0) {
        $error = 'Informe um preço válido.';
    } elseif (!in_array($p['license_type'], ['perpetual','annual','monthly','none'], true)) {
        $error = 'Modelo de licença inválido.';
    } else {
        $check = $pdo->prepare('SELECT id FROM products WHERE slug = ? AND id <> ? LIMIT 1');
        $check->execute([$p['slug'], $id]);

        if ($check->fetch()) {
            $error = 'Este endereço já está sendo utilizado. Escolha outro slug.';
        } else {
            $oldImage = (string)($p['cover_image'] ?? '');
            $oldInstaller = (string)($p['file_path'] ?? '');
            $newImage = null;
            $newInstaller = null;

            try {
                if (!empty($_FILES['cover_upload'])) {
                    $newImage = store_save_upload($_FILES['cover_upload'], 'image');
                    if ($newImage !== null) $p['cover_image'] = $newImage;
                }
                if (!empty($_FILES['installer_upload'])) {
                    $newInstaller = store_save_upload($_FILES['installer_upload'], 'installer');
                    if ($newInstaller !== null) $p['file_path'] = $newInstaller;
                }

                $values = [
                    $p['name'], $p['slug'], $p['category'] ?: 'Software',
                    $p['short_description'], $p['description'],
                    number_format((float)$p['price'], 2, '.', ''),
                    $p['license_type'], $p['max_activations'], $p['version'],
                    $p['cover_image'], $p['file_path'], $p['is_published']
                ];

                if ($id > 0) {
                    $sql = 'UPDATE products SET name=?, slug=?, category=?, short_description=?, description=?, price=?, license_type=?, max_activations=?, version=?, cover_image=?, file_path=?, is_published=? WHERE id=?';
                    $values[] = $id;
                } else {
                    $sql = 'INSERT INTO products (name,slug,category,short_description,description,price,license_type,max_activations,version,cover_image,file_path,is_published) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)';
                }

                $pdo->prepare($sql)->execute($values);

                if ($newImage && $oldImage && $oldImage !== $newImage) store_remove_managed_file($oldImage, 'image');
                if ($newInstaller && $oldInstaller && $oldInstaller !== $newInstaller) store_remove_managed_file($oldInstaller, 'installer');

                header('Location: produtos.php?salvo=1');
                exit;
            } catch (Throwable $e) {
                if ($newImage) store_remove_managed_file($newImage, 'image');
                if ($newInstaller) store_remove_managed_file($newInstaller, 'installer');
                error_log('Toplevel produto-form: ' . $e->getMessage());
                $error = $e instanceof RuntimeException ? $e->getMessage() : 'Não foi possível salvar o produto. Consulte o log do PHP.';
            }
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= $id ? 'Editar' : 'Cadastrar' ?> produto | Toplevel</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
<style>
.upload-box{border:1px dashed #aebbb4;border-radius:12px;padding:14px;background:#fbfcfb}
.upload-preview{max-width:180px;max-height:120px;object-fit:contain;border-radius:8px;display:block;margin-top:10px}
.file-current{font-size:.85rem;color:#647067;overflow-wrap:anywhere}
</style>
</head>
<body>
<nav class="navbar navbar-dark" style="background:#101820"><div class="container"><a class="navbar-brand" href="index.php">TOPLEVEL · LOJA</a><a class="text-white" href="logout.php">Sair</a></div></nav>
<main class="container py-5" style="max-width:950px">
<a href="produtos.php" class="text-decoration-none">← Voltar aos produtos</a>
<h1 class="h2 mt-3 mb-4"><?= $id ? 'Editar produto' : 'Cadastrar produto' ?></h1>
<?php if ($error): ?><div class="alert alert-danger"><?= store_h($error) ?></div><?php endif; ?>

<form method="post" enctype="multipart/form-data" class="contact-panel">
<input type="hidden" name="_csrf" value="<?= store_h(store_csrf()) ?>">
<div class="row g-3">
<div class="col-md-8"><label class="form-label">Nome do produto *</label><input class="form-control" name="name" required value="<?= store_h((string)$p['name']) ?>"></div>
<div class="col-md-4"><label class="form-label">Endereço (slug)</label><input class="form-control" name="slug" value="<?= store_h((string)$p['slug']) ?>" placeholder="Gerado pelo nome"></div>
<div class="col-md-6"><label class="form-label">Categoria</label><input class="form-control" name="category" value="<?= store_h((string)$p['category']) ?>"></div>
<div class="col-md-3"><label class="form-label">Preço (R$) *</label><input class="form-control" type="number" min="0" step="0.01" name="price" required value="<?= store_h((string)$p['price']) ?>"></div>
<div class="col-md-3"><label class="form-label">Versão</label><input class="form-control" name="version" value="<?= store_h((string)$p['version']) ?>"></div>
<div class="col-12"><label class="form-label">Resumo para o catálogo *</label><input class="form-control" maxlength="500" name="short_description" required value="<?= store_h((string)$p['short_description']) ?>"></div>
<div class="col-12"><label class="form-label">Descrição completa</label><textarea class="form-control" rows="6" name="description"><?= store_h((string)$p['description']) ?></textarea></div>
<div class="col-md-4"><label class="form-label">Modelo de licença</label><select class="form-select" name="license_type"><?php foreach (['perpetual'=>'Perpétua','annual'=>'Anual','monthly'=>'Mensal','none'=>'Sem licença'] as $key=>$label): ?><option value="<?= store_h($key) ?>" <?= $p['license_type']===$key?'selected':'' ?>><?= store_h($label) ?></option><?php endforeach; ?></select></div>
<div class="col-md-4"><label class="form-label">Limite de computadores</label><input class="form-control" type="number" min="1" name="max_activations" value="<?= store_h((string)$p['max_activations']) ?>"></div>
<div class="col-md-4"><label class="form-label">Publicação</label><select class="form-select" name="is_published"><option value="0" <?= (int)$p['is_published']===0?'selected':'' ?>>Rascunho</option><option value="1" <?= (int)$p['is_published']===1?'selected':'' ?>>Publicado</option></select></div>

<div class="col-md-6">
<label class="form-label fw-semibold">Imagem de capa</label>
<div class="upload-box">
<input class="form-control" type="file" name="cover_upload" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp">
<div class="form-text">Selecione uma imagem JPG, PNG ou WEBP. Máximo 5 MB. Apenas uma capa por produto.</div>
<?php if (!empty($p['cover_image'])): ?>
<div class="file-current mt-2">Capa atual: <?= store_h(basename((string)$p['cover_image'])) ?></div>
<img class="upload-preview" src="../<?= store_h((string)$p['cover_image']) ?>" alt="Capa atual">
<?php endif; ?>
</div>
</div>

<div class="col-md-6">
<label class="form-label fw-semibold">Instalador para download</label>
<div class="upload-box">
<input class="form-control" type="file" name="installer_upload" accept=".zip,.exe,.msi,application/zip,application/x-msdownload,application/octet-stream">
<div class="form-text">Selecione um único arquivo ZIP, EXE ou MSI. Máximo 500 MB. Será guardado em pasta privada, não acessível diretamente pelo site.</div>
<?php if (!empty($p['file_path'])): ?>
<div class="file-current mt-2">Instalador atual: <?= store_h(basename((string)$p['file_path'])) ?></div>
<?php else: ?>
<div class="file-current mt-2">Nenhum instalador enviado.</div>
<?php endif; ?>
</div>
</div>

<div class="col-12"><button class="btn btn-dark px-4 py-3" type="submit">Salvar produto</button> <a href="produtos.php" class="btn btn-outline-secondary px-4 py-3">Cancelar</a></div>
</div>
</form>
<p class="small text-secondary mt-3">Ao editar, se não selecionar novos arquivos, a capa e o instalador atuais serão mantidos. O instalador não ficará exposto por URL pública; a entrega será feita por endpoint protegido após confirmação do pagamento.</p>
</main>
</body>
</html>
