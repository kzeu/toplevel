<?php
require __DIR__ . '/_init.php';
store_admin_required();

$pdo = store_db();
$error = '';
$success = isset($_GET['salvo']) ? 'Produto salvo com sucesso.' : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_product') {
    store_check_csrf();
    $deleteId = (int)($_POST['product_id'] ?? 0);

    try {
        $q = $pdo->prepare('SELECT id, cover_image, file_path FROM products WHERE id = ? LIMIT 1');
        $q->execute([$deleteId]);
        $product = $q->fetch();

        if (!$product) {
            $error = 'Produto não encontrado.';
        } else {
            $used = $pdo->prepare('SELECT COUNT(*) FROM order_items WHERE product_id = ?');
            $used->execute([$deleteId]);

            if ((int)$used->fetchColumn() > 0) {
                $error = 'Este produto já possui pedidos vinculados. Para preservar o histórico, despublique-o em vez de excluí-lo.';
            } else {
                $pdo->prepare('DELETE FROM products WHERE id = ?')->execute([$deleteId]);

                // Excluir somente arquivos que estejam dentro das pastas gerenciadas pela loja.
                $imageBase = realpath(dirname(__DIR__) . '/assets/uploads/products');
                $imagePath = !empty($product['cover_image'])
                    ? realpath(dirname(__DIR__) . '/' . ltrim((string)$product['cover_image'], '/\\'))
                    : false;
                if ($imageBase && $imagePath && strpos($imagePath, $imageBase . DIRECTORY_SEPARATOR) === 0 && is_file($imagePath)) {
                    @unlink($imagePath);
                }

                $downloadBase = realpath(defined('STORE_DOWNLOAD_DIR') ? STORE_DOWNLOAD_DIR : dirname(__DIR__) . '/storage/downloads');
                $downloadPath = !empty($product['file_path']) && $downloadBase
                    ? realpath($downloadBase . DIRECTORY_SEPARATOR . basename((string)$product['file_path']))
                    : false;
                if ($downloadBase && $downloadPath && strpos($downloadPath, $downloadBase . DIRECTORY_SEPARATOR) === 0 && is_file($downloadPath)) {
                    @unlink($downloadPath);
                }

                header('Location: produtos.php?excluido=1');
                exit;
            }
        }
    } catch (Throwable $e) {
        error_log('Toplevel excluir produto: ' . $e->getMessage());
        $error = 'Não foi possível excluir o produto. Verifique se há pedidos ou licenças vinculados.';
    }
}

if (isset($_GET['excluido'])) $success = 'Produto excluído com sucesso.';

$rows = $pdo->query('SELECT id, name, slug, category, price, version, is_published, updated_at FROM products ORDER BY id DESC')->fetchAll();
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Produtos | Toplevel</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-dark" style="background:#101820"><div class="container">
<a class="navbar-brand" href="index.php">TOPLEVEL · LOJA</a>
<div class="d-flex gap-3"><a class="text-white" href="index.php">Painel</a><a class="text-white" href="../loja.php" target="_blank" rel="noopener">Ver loja</a><a class="text-white" href="logout.php">Sair</a></div>
</div></nav>
<main class="container py-5">
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4"><div><span class="section-kicker">Catálogo</span><h1 class="h2 mb-0">Produtos</h1><p class="text-secondary mb-0">Gerencie todos os produtos digitais da ToplevelSistemas.</p></div><a class="btn btn-dark" href="produto-form.php">+ Cadastrar produto</a></div>
<?php if ($success): ?><div class="alert alert-success"><?= store_h($success) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?= store_h($error) ?></div><?php endif; ?>
<div class="contact-panel"><div class="table-responsive"><table class="table table-hover align-middle">
<thead><tr><th>Produto</th><th>Categoria</th><th>Preço</th><th>Versão</th><th>Status</th><th class="text-end">Ações</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?><tr>
<td><strong><?= store_h((string)$r['name']) ?></strong><br><small class="text-secondary">/<?= store_h((string)$r['slug']) ?></small></td>
<td><?= store_h((string)$r['category']) ?></td>
<td>R$ <?= number_format((float)$r['price'], 2, ',', '.') ?></td>
<td><?= store_h((string)($r['version'] ?? '-')) ?></td>
<td><?php if ((int)$r['is_published'] === 1): ?><span class="badge bg-success">Publicado</span><?php else: ?><span class="badge bg-secondary">Rascunho</span><?php endif; ?></td>
<td class="text-end text-nowrap">
<a class="btn btn-sm btn-outline-dark" href="produto-form.php?id=<?= (int)$r['id'] ?>">Editar</a>
<form method="post" class="d-inline" onsubmit="return confirm('Tem certeza que deseja excluir este produto? Esta ação não pode ser desfeita.');">
<input type="hidden" name="_csrf" value="<?= store_h(store_csrf()) ?>">
<input type="hidden" name="action" value="delete_product">
<input type="hidden" name="product_id" value="<?= (int)$r['id'] ?>">
<button type="submit" class="btn btn-sm btn-outline-danger">Excluir</button>
</form>
</td>
</tr><?php endforeach; ?>
<?php if (!$rows): ?><tr><td colspan="6" class="text-center text-secondary py-4">Nenhum produto cadastrado.</td></tr><?php endif; ?>
</tbody></table></div></div>
</main></body></html>
