<?php
require __DIR__ . '/config/config.php';
require __DIR__ . '/config/store.php';
$slug = trim((string)($_GET['slug'] ?? ''));
$q = store_db()->prepare('SELECT * FROM products WHERE slug = ? AND is_published = 1 LIMIT 1');
$q->execute([$slug]);
$product = $q->fetch();
if (!$product) { http_response_code(404); $pageTitle = 'Produto não encontrado'; }
else { $pageTitle = (string)$product['name']; }
$pageDescription = $product ? (string)$product['short_description'] : 'Produto não encontrado.';
require __DIR__ . '/includes/header.php';
?>
<section class="page-hero"><div class="container"><span class="eyebrow">Produto digital</span><h1><?= $product ? store_h((string)$product['name']) : 'Produto não encontrado' ?></h1><?php if ($product): ?><p><?= store_h((string)$product['short_description']) ?></p><?php endif; ?></div></section>
<section class="section-pad"><div class="container" style="max-width:980px">
<?php if (!$product): ?><div class="empty-state"><p>Este produto não está disponível.</p><a href="loja.php" class="btn btn-dark">Voltar à loja</a></div>
<?php else: ?><div class="row g-5"><div class="col-lg-7"><span class="section-kicker"><?= store_h((string)$product['category']) ?></span><h2 class="h3 mt-2">Sobre o produto</h2><div class="content-prose"><?= nl2br(store_h((string)$product['description'])) ?></div><p class="small text-secondary mt-4">Versão: <?= store_h((string)$product['version']) ?> · Licença: <?= store_h(['perpetual'=>'Perpétua','annual'=>'Anual','monthly'=>'Mensal','none'=>'Sem licença'][$product['license_type']] ?? 'Não informada') ?></p></div>
<div class="col-lg-5"><div class="contact-panel"><div class="text-secondary small">Valor do produto</div><div class="display-6 fw-bold my-2">R$ <?= number_format((float)$product['price'],2,',','.') ?></div><p class="small text-secondary">As opções de pagamento e entrega serão disponibilizadas após a integração do checkout.</p><div class="alert alert-info small">Checkout em configuração. Ainda não realize pagamentos por esta página.</div><a href="loja.php" class="btn btn-outline-dark w-100">Voltar ao catálogo</a></div></div></div><?php endif; ?>
</div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
